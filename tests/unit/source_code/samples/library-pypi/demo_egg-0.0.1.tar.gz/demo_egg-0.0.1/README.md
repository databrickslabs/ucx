### Demo Egg
```
    https://packaging.python.org/tutorials/packaging-projects/
```