# Demo wheel

This contains sources for a wheel. The wheel is a Python package format, and it is the standard binary distribution format for Python packages.

Use `make dist` to rebuild the wheel after changing any content in this folder.
