from setuptools import setup

setup(
    name="thingy",
    version="0.0.1",
    description='This package does nothing useful and is meant for testing eggs.',
)
