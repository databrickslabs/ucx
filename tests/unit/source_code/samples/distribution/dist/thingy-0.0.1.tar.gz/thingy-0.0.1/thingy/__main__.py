from . import install_logger, main

if __name__ == '__main__':
    install_logger()
    main()
